import pygame
import asyncio
import random
import math

class Enemy():
    def __init__(self, x, y, speed, size):
        self.x = x
        self.y = y
        self.type = random.randint(0, 3)
        if self.type == 0:
            self.pic = pygame.image.load("assets/Fish04_A.png")
            self.pic2 = pygame.image.load("assets/Fish04_B.png")
        if self.type == 1:
            self.pic = pygame.image.load("assets/Fish01_A.png")
            self.pic2 = pygame.image.load("assets/Fish01_B.png")
        if self.type == 2:
            self.pic = pygame.image.load("assets/Fish02_A.png")
            self.pic2 = pygame.image.load("assets/Fish02_B.png")
        if self.type == 3:
            self.pic = pygame.image.load("assets/Fish03_A.png")
            self.pic2 = pygame.image.load("assets/Fish03_B.png")
        self.speed = speed
        self.size = size

        self.pic = pygame.transform.scale(self.pic, (int(self.size*1.25), self.size))
        self.pic2 = pygame.transform.scale(self.pic2, (int(self.size*1.25), self.size))
        self.hitbox = pygame.Rect(self.x, self.y, int(self.size*1.25), self.size)
        self.animation_timer_max = 16
        self.animation_timer = self.animation_timer_max
        self.animation_frame = 0

        if self.speed < 0:
            self.pic = pygame.transform.flip(self.pic, True, False)
            self.pic2 = pygame.transform.flip(self.pic2, True, False)
            

    def update(self, screen):
        self.animation_timer -= 1
        if self.animation_timer <= 0:
            self.animation_timer = self.animation_timer_max
            self.animation_frame += 1
            if self.animation_frame > 1:
                self.animation_frame = 0
        self.x += self.speed
        self.hitbox.x += self.speed
        if self.animation_frame == 0:
            screen.blit(self.pic, (self.x, self.y))
        else:
            screen.blit(self.pic2, (self.x, self.y))

# Start the game
pygame.init()
pygame.mixer.init()

eat_sounds = [
    pygame.mixer.Sound(f"assets/sfx/Eating{i}.ogg") for i in range(1, 7)
]
transition_sound = pygame.mixer.Sound("assets/sfx/Aquatic_transition.ogg")
spooky_transition_sound = pygame.mixer.Sound("assets/sfx/Spooky_transition.ogg")

# LOAD VOICE LINES FROM assets/voice/ (MP3 FORMAT)
voice_sounds = {}
try:
    voice_sounds["player1"] = pygame.mixer.Sound("assets/voice/Player1.mp3")
    voice_sounds["player2"] = pygame.mixer.Sound("assets/voice/Player2.mp3")
    voice_sounds["player3"] = pygame.mixer.Sound("assets/voice/Player3.mp3")
    voice_sounds["necro1"] = pygame.mixer.Sound("assets/voice/Necromancer1.mp3")
    voice_sounds["necro2"] = pygame.mixer.Sound("assets/voice/Necromancer2.mp3")
    voice_sounds["necro3"] = pygame.mixer.Sound("assets/voice/Necromancer3.mp3")
    voice_sounds["necro4"] = pygame.mixer.Sound("assets/voice/Necromancer4.mp3")
except Exception as e:
    print(f"Voice loading warning: {e}")

def play_voice(key):
    pygame.mixer.stop()
    if key in voice_sounds and voice_sounds[key]:
        voice_sounds[key].play()

game_width = 1000
game_height = 650
screen = pygame.display.set_mode((game_width, game_height))
clock = pygame.time.Clock()

background_pic = pygame.image.load("assets/Scene_A.png")
background_pic2 = pygame.image.load("assets/Scene_B.png")
player_pic = pygame.image.load("assets/Fish05_A.png")
player_pic2 = pygame.image.load("assets/Fish05_B.png")
player_eating_pic = pygame.image.load("assets/Fish05_open.png")
bubble_pic = pygame.image.load("assets/Bubble.png")
whirlpool_pic = pygame.image.load("assets/whirlpool.png")

# LOAD RAW BIG NECROMANCER FRAMES (03 TO 10)
necromancer_raw_frames = []
for i in range(3, 11):
    frame_num = f"{i:02d}"
    file_path = f"assets/Necro/frame_{frame_num}.png"
    raw_img = pygame.image.load(file_path).convert_alpha()
    necromancer_raw_frames.append(raw_img)

# LOAD SPELL FRAMES (frame_01 to frame_12) FROM assets/slam/
spell_frames = []
for i in range(1, 13):
    frame_num = f"{i:02d}"
    file_path = f"assets/slam/frame_{frame_num}.png"
    try:
        raw_img = pygame.image.load(file_path)
        scaled_img = pygame.transform.scale(raw_img, (414, 404)).convert_alpha()
        spell_frames.append(scaled_img)
    except Exception as e:
        print(f"Spell frame loading warning ({file_path}): {e}")

# LOAD SLAM FRAMES (frame_01 to frame_12) FROM assets/Slam/
slam_frames = []
for i in range(1, 13):
    frame_num = f"{i:02d}"
    file_path = f"assets/Slam/frame_{frame_num}.png"
    try:
        raw_img = pygame.image.load(file_path)
        scaled_img = pygame.transform.scale(raw_img, (414, 404)).convert_alpha()
        slam_frames.append(scaled_img)
    except Exception as e:
        print(f"Slam frame loading warning ({file_path}): {e}")

# LOAD LASER FRAMES (1 TO 14) FROM assets/Lazar/
laser_frames = []
for i in range(1, 15):
    frame_num = f"{i:02d}"
    file_path = f"assets/Lazar/frame_{frame_num}.png"
    try:
        raw_img = pygame.image.load(file_path)
        scaled_img = pygame.transform.scale(raw_img, (650, 160)).convert_alpha()
        laser_frames.append(scaled_img)
    except Exception as e:
        print(f"Laser frame loading warning ({file_path}): {e}")

# LOAD BOSS OPENING / INTRO CINEMATIC FRAMES (frame_01 to frame_53) FROM assets/frames/
boss_opening_frames = []
for i in range(1, 54):
    file_path = f"assets/frames/frame_{i:02d}.png"
    try:
        raw_img = pygame.image.load(file_path)
        scaled_img = pygame.transform.scale(raw_img, (414, 404)).convert_alpha()
        boss_opening_frames.append(scaled_img)
    except Exception as e:
        print(f"Boss opening frame loading warning ({file_path}): {e}")

# LOAD DEATH FRAMES (frame_01 to frame_52) FROM assets/death/
death_frames = []
for i in range(1, 53):
    file_path = f"assets/death/frame_{i:02d}.png"
    try:
        raw_img = pygame.image.load(file_path)
        scaled_img = pygame.transform.scale(raw_img, (414, 404)).convert_alpha()
        death_frames.append(scaled_img)
    except Exception as e:
        print(f"Death frame loading warning ({file_path}): {e}")

necromancer_anim_timer_max = 8
necromancer_anim_timer = necromancer_anim_timer_max
necromancer_frame_index = 0

bg_animation_timer_max = 35
bg_animation_timer = bg_animation_timer_max
bg_animation_frame = 0

player_starting_x = 480
player_starting_y = 310
player_starting_size = 20

player_x = player_starting_x
player_y = player_starting_y
player_speed = 7

player_size = player_starting_size
player_facing_left = False
player_hitbox = pygame.Rect(player_x, player_y, int(player_size*1.25), player_size)
player_alive = False

game_state = "intro"

# BOSS STATS & SPELL TRACKER
dialogue_step = 0
dialogue_finished = False
dialogue_alpha = 0

# Boss Opening Animation States
boss_opening_active = False
boss_opening_index = 0
boss_opening_timer = 0

necro_max_health = 100.0
necro_health = 100.0
necro_is_dead = False
necro_death_anim_index = 0
necro_death_anim_timer = 0
boss_match_over = False  # Track if boss win/loss sequence has ended
boss_result_text = ""

player_max_health = 100.0
player_health = 100.0

boss_spell_timer = 180
active_debuff = None
debuff_duration = 0
warning_message = ""
warning_timer = 0

# Spell animation state
spell_anim_active = False
spell_seq_index = 0
spell_anim_timer = 0

# Slam animation state
slam_anim_active = False
slam_seq_index = 0
slam_anim_timer = 0
melee_hit_cooldown = 0

# Laser attack variables with 0.5 second telegraph window
laser_delay_timer = 0
laser_charging = False
laser_charge_timer = 0
locked_laser_y = 0
laser_active = False
laser_seq_index = 0
laser_anim_timer = 0
laser_hit_dealt = False

# Void floating dust particles
void_dust = [[random.randint(0, game_width), random.randint(0, game_height), random.uniform(0.2, 0.8), random.uniform(-0.3, 0.3), random.randint(1, 3)] for _ in range(80)]

player_eating_timer_max = 25
player_eating_timer = 0
player_swimming_timer_max = 16
player_swimming_timer = player_swimming_timer_max
player_swimming_frame = 0

FONT_FILE = "assets/Orbitron-ExtraBold.ttf"
souls = 0
total_souls = 85

try:
    souls_font = pygame.font.Font(FONT_FILE, 36)
    small_font = pygame.font.Font(FONT_FILE, 22)
except FileNotFoundError:
    souls_font = pygame.font.SysFont("Default", 36)
    small_font = pygame.font.SysFont("Default", 22)

play_button_pic = pygame.image.load("assets/BtnPlayIcon.png")
play_button_x = game_width/2 - play_button_pic.get_width()/2
play_button_y = game_height/2 - play_button_pic.get_height()/2
title_pic = pygame.image.load("assets/title.png")
title_x = game_width/2 - title_pic.get_width()/2
title_y = play_button_y - 150

upgrades_button_width = 240
upgrades_button_height = 60
upgrades_button_x = game_width/2 - upgrades_button_width/2
upgrades_button_y = play_button_y + play_button_pic.get_height() + 20

enemy_timer_max = 40
enemy_timer = enemy_timer_max

enemies = []
enemies_to_remove = []

transitioning = False
transition_type = "bubble"
transition_progress = 0.0
next_state = None
bubble_size_grid = 50
cols = game_width // bubble_size_grid + 4
rows = game_height // bubble_size_grid + 4
bubble_offsets = [[random.uniform(0.0, 0.4) for _ in range(cols)] for _ in range(rows)]

whirlpool_x = game_width / 2
whirlpool_y = game_height / 2
whirlpool_angle = 0

def draw_upgrades_button():
    pygame.draw.rect(screen, (30, 90, 140), (upgrades_button_x, upgrades_button_y, upgrades_button_width, upgrades_button_height), border_radius=12)
    pygame.draw.rect(screen, (100, 180, 220), (upgrades_button_x, upgrades_button_y, upgrades_button_width, upgrades_button_height), 3, border_radius=12)
    upgrades_text = souls_font.render("UPGRADES", True, (255, 255, 255))
    screen.blit(upgrades_text, (upgrades_button_x + (upgrades_button_width - upgrades_text.get_width()) / 2, upgrades_button_y + (upgrades_button_height - upgrades_text.get_height()) / 2))

async def main():
    global player_x, player_y, player_facing_left, player_size, player_alive, enemy_timer, souls, total_souls, enemies_to_remove, bg_animation_timer, bg_animation_frame, player_eating_timer, player_swimming_timer, player_swimming_frame, game_state, transitioning, transition_type, transition_progress, next_state, necromancer_anim_timer, necromancer_frame_index, dialogue_step, dialogue_finished, dialogue_alpha, whirlpool_angle, necro_health, necro_is_dead, necro_death_anim_index, necro_death_anim_timer, player_health, boss_spell_timer, active_debuff, debuff_duration, warning_message, warning_timer, laser_delay_timer, laser_charging, laser_charge_timer, locked_laser_y, laser_active, laser_seq_index, laser_anim_timer, laser_hit_dealt, spell_anim_active, spell_seq_index, spell_anim_timer, slam_anim_active, slam_seq_index, slam_anim_timer, melee_hit_cooldown, boss_opening_active, boss_opening_index, boss_opening_timer, boss_match_over, boss_result_text
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if game_state in ["upgrades", "boss_dialogue", "intro"] and not transitioning:
                        transitioning = True
                        transition_type = "fade"
                        transition_progress = 0.0
                        next_state = "menu"
                    else:
                        running = False
                
                if game_state == "intro" and event.key == pygame.K_SPACE and not transitioning:
                    spooky_transition_sound.play()
                    transitioning = True
                    transition_type = "fade"
                    transition_progress = 0.0
                    next_state = "menu"

                # ADVANCE BOSS DIALOGUE ON SPACEBAR
                elif game_state == "boss_dialogue" and event.key == pygame.K_SPACE and not transitioning:
                    if not dialogue_finished and not boss_opening_active:
                        dialogue_step += 1
                        if dialogue_step == 1:
                            play_voice("necro1")
                        elif dialogue_step == 2:
                            play_voice("player2")
                        elif dialogue_step == 3:
                            play_voice("necro2")
                        elif dialogue_step == 4:
                            play_voice("necro3")
                        elif dialogue_step == 5:
                            play_voice("player3")
                        elif dialogue_step == 6:
                            play_voice("necro4")
                        elif dialogue_step > 6:
                            dialogue_finished = True
                            # TRIGGER BOSS OPENING CINEMATIC AFTER DIALOGUE
                            boss_opening_active = True
                            boss_opening_index = 0
                            boss_opening_timer = 0

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not transitioning:
                mouse_x, mouse_y = event.pos
                if game_state == "menu":
                    if play_button_x < mouse_x < play_button_x + play_button_pic.get_width() and play_button_y < mouse_y < play_button_y + play_button_pic.get_height():
                        transition_sound.play()
                        transitioning = True
                        transition_type = "bubble"
                        transition_progress = 0.0
                        next_state = "game"
                    elif upgrades_button_x < mouse_x < upgrades_button_x + upgrades_button_width and upgrades_button_y < mouse_y < upgrades_button_y + upgrades_button_height:
                        transitioning = True
                        transition_type = "fade"
                        transition_progress = 0.0
                        next_state = "upgrades"
                elif game_state == "game" and not player_alive:
                    if play_button_x < mouse_x < play_button_x + play_button_pic.get_width() and play_button_y < mouse_y < play_button_y + play_button_pic.get_height():
                        transition_sound.play()
                        transitioning = True
                        transition_type = "bubble"
                        transition_progress = 0.0
                        next_state = "restart_game"
                    elif upgrades_button_x < mouse_x < upgrades_button_x + upgrades_button_width and upgrades_button_y < mouse_y < upgrades_button_y + upgrades_button_height:
                        transitioning = True
                        transition_type = "fade"
                        transition_progress = 0.0
                        next_state = "upgrades"
                elif game_state in ["upgrades"]:
                    transitioning = True
                    transition_type = "fade"
                    transition_progress = 0.0
                    next_state = "menu"

        if game_state not in ["intro", "boss_dialogue"]:
            bg_animation_timer -= 1
            if bg_animation_timer <= 0:
                bg_animation_frame += 1
                if bg_animation_frame > 1:
                    bg_animation_frame = 0
                bg_animation_timer = bg_animation_timer_max

            if bg_animation_frame == 0:
                screen.blit(background_pic, (0, 0))
            else:
                screen.blit(background_pic2, (0, 0))
        else:
            screen.fill((10, 8, 15))
            
            for p in void_dust:
                p[1] += p[2]
                p[0] += p[3]
                if p[1] > game_height:
                    p[1] = 0
                    p[0] = random.randint(0, game_width)
                if p[0] < 0:
                    p[0] = game_width
                elif p[0] > game_width:
                    p[0] = 0
                pygame.draw.circle(screen, (70, 60, 95), (int(p[0]), int(p[1])), p[4])

        if game_state == "intro":
            necromancer_anim_timer -= 1
            if necromancer_anim_timer <= 0:
                necromancer_anim_timer = necromancer_anim_timer_max
                necromancer_frame_index = (necromancer_frame_index + 1) % len(necromancer_raw_frames)

            current_necro_img = pygame.transform.scale(necromancer_raw_frames[necromancer_frame_index], (414, 404)).convert_alpha()
            screen.blit(current_necro_img, (game_width/2 - current_necro_img.get_width()/2, game_height/2 - current_necro_img.get_height()/2 - 30))

            prompt_text = small_font.render("PRESS SPACE TO CONTINUE", True, (180, 180, 180))
            screen.blit(prompt_text, (game_width/2 - prompt_text.get_width()/2, game_height - 80))

        elif game_state == "boss_dialogue":
            if not dialogue_finished:
                necromancer_anim_timer -= 1
                if necromancer_anim_timer <= 0:
                    necromancer_anim_timer = necromancer_anim_timer_max
                    necromancer_frame_index = (necromancer_frame_index + 1) % len(necromancer_raw_frames)

                current_necro_img = pygame.transform.scale(necromancer_raw_frames[necromancer_frame_index], (414, 404)).convert_alpha()
                screen.blit(current_necro_img, (game_width/2 - current_necro_img.get_width()/2, game_height/2 - current_necro_img.get_height()/2 - 60))

                dialogue_box = pygame.Rect(100, game_height - 160, game_width - 200, 110)
                pygame.draw.rect(screen, (15, 15, 20), dialogue_box, border_radius=12)
                pygame.draw.rect(screen, (100, 100, 120), dialogue_box, 3, border_radius=12)

                if dialogue_step == 0:
                    speaker = "Player"
                    text = "Where.. am I?"
                elif dialogue_step == 1:
                    speaker = "Necromancer"
                    text = "You are in the void, Hand Over the souls you have collected"
                elif dialogue_step == 2:
                    speaker = "Player"
                    text = "Hell no! I gathered them myself!"
                elif dialogue_step == 3:
                    speaker = "Necromancer"
                    text = "Arrogant brat! DO YOU WANT TO DIE?"
                elif dialogue_step == 4:
                    speaker = "Necromancer"
                    text = "Hand over your soul... and I will spare you"
                elif dialogue_step == 5:
                    speaker = "Player"
                    text = "HELL NO! GET THE FUCK OUT"
                elif dialogue_step == 6:
                    speaker = "Necromancer"
                    text = "You leave me no choice..."

                speaker_surf = small_font.render(speaker, True, (220, 180, 50))
                text_surf = small_font.render(text, True, (255, 255, 255))
                prompt_surf = small_font.render("[Press SPACE to Continue]", True, (140, 140, 140))

                screen.blit(speaker_surf, (dialogue_box.x + 20, dialogue_box.y + 15))
                screen.blit(text_surf, (dialogue_box.x + 20, dialogue_box.y + 50))
                screen.blit(prompt_surf, (dialogue_box.right - prompt_surf.get_width() - 20, dialogue_box.bottom - 30))
            
            elif boss_opening_active:
                # PLAY BOSS OPENING ANIMATION SEQUENCE
                boss_opening_timer += 1
                if boss_opening_timer >= 3:  # ~3 ticks per frame
                    boss_opening_timer = 0
                    boss_opening_index += 1
                    if boss_opening_index >= len(boss_opening_frames):
                        boss_opening_active = False

                if boss_opening_frames:
                    current_opening_img = boss_opening_frames[min(boss_opening_index, len(boss_opening_frames) - 1)]
                    flipped_opening = pygame.transform.flip(current_opening_img, True, False)
                    screen.blit(flipped_opening, (game_width - flipped_opening.get_width() - 80, game_height/2 - flipped_opening.get_height()/2))
            
            elif not boss_match_over:
                if dialogue_alpha < 255:
                    dialogue_alpha += 5

                # Check Player Health for Loss Condition
                if player_health <= 0:
                    boss_match_over = True
                    boss_result_text = "You Lose..."

                # Necromancer health decay over time
                if necro_health > 0 and not necro_is_dead:
                    necro_health -= 0.04
                    if necro_health <= 0:
                        necro_health = 0.0
                        necro_is_dead = True
                        necro_death_anim_index = 0
                        necro_death_anim_timer = 0
                        warning_message = "NECROMANCER DEFEATED!"
                        warning_timer = 180

                # Handle Boss Death Animation Sequence (~3 ticks per frame across 52 frames)
                if necro_is_dead and death_frames:
                    necro_death_anim_timer += 1
                    if necro_death_anim_timer >= 3:
                        necro_death_anim_timer = 0
                        if necro_death_anim_index < len(death_frames) - 1:
                            necro_death_anim_index += 1
                        else:
                            # Death animation finished playing -> Trigger Win Screen
                            boss_match_over = True
                            boss_result_text = "You win.... But was it worth it?"

                if melee_hit_cooldown > 0:
                    melee_hit_cooldown -= 1

                # Check Proximity Melee Damage
                boss_center_x = game_width - 80 - 207
                boss_center_y = game_height / 2
                distance_to_boss = math.hypot(player_x - boss_center_x, player_y - boss_center_y)
                
                if distance_to_boss < 200 and melee_hit_cooldown == 0 and not slam_anim_active and not laser_active and not laser_charging and not spell_anim_active and not necro_is_dead:
                    player_health -= 40.0
                    melee_hit_cooldown = 120
                    slam_anim_active = True
                    slam_seq_index = 0
                    slam_anim_timer = 0
                    active_debuff = "inverted"
                    debuff_duration = 90
                    warning_message = "NECROMANCER SLAM! CONTROLS INVERTED!"
                    warning_timer = 50

                if slam_anim_active and slam_frames:
                    slam_anim_timer += 1
                    if slam_anim_timer >= 4:
                        slam_anim_timer = 0
                        slam_seq_index += 1
                        if slam_seq_index >= len(slam_frames):
                            slam_anim_active = False

                # Boss Spell & Laser Mechanics Logic
                if not necro_is_dead:
                    boss_spell_timer -= 1
                    if boss_spell_timer <= 0 and not laser_active and not laser_charging and laser_delay_timer == 0 and not spell_anim_active and not slam_anim_active:
                        boss_spell_timer = random.randint(180, 300)
                        chosen_spell = random.choice(["frozen", "inverted"])
                        active_debuff = chosen_spell
                        debuff_duration = 90
                        
                        spell_anim_active = True
                        spell_seq_index = 0
                        spell_anim_timer = 0

                        if chosen_spell == "frozen":
                            warning_message = "NECROMANCER CASTS FREEZE!"
                        else:
                            warning_message = "NECROMANCER INVERTS CONTROLS!"
                        warning_timer = 60

                if spell_anim_active and spell_frames:
                    spell_anim_timer += 1
                    if spell_anim_timer >= 4:
                        spell_anim_timer = 0
                        spell_seq_index += 1
                        if spell_seq_index >= len(spell_frames):
                            spell_anim_active = False

                if debuff_duration > 0:
                    debuff_duration -= 1
                    if debuff_duration == 0:
                        if active_debuff == "frozen" and not necro_is_dead:
                            laser_delay_timer = 60
                            warning_message = "LASER CHARGING..."
                            warning_timer = 60
                        active_debuff = None

                # Handle Laser Delay countdown -> locks Y and triggers 0.5s charging indicator
                if laser_delay_timer > 0 and not necro_is_dead:
                    laser_delay_timer -= 1
                    if laser_delay_timer == 0:
                        laser_charging = True
                        laser_charge_timer = 30  # 0.5 second warning window
                        locked_laser_y = player_y  # Lock in Y coordinate so it doesn't track live player
                        warning_message = "DODGE! LASER INCOMING!"
                        warning_timer = 30

                if laser_charging and not necro_is_dead:
                    laser_charge_timer -= 1
                    if laser_charge_timer <= 0:
                        laser_charging = False
                        laser_active = True
                        laser_seq_index = 0
                        laser_anim_timer = 0
                        laser_hit_dealt = False
                        warning_message = "LASER BEAM FIRED!"
                        warning_timer = 30

                if laser_active and laser_frames:
                    laser_anim_timer += 1
                    if laser_anim_timer >= 4:
                        laser_anim_timer = 0
                        laser_seq_index += 1
                        if laser_seq_index >= len(laser_frames):
                            laser_active = False
                            laser_seq_index = 0

                    if laser_active:
                        boss_x_pos = game_width - 80 - 414
                        laser_rect = pygame.Rect(boss_x_pos - 650, locked_laser_y - 40, 650, 100)
                        player_rect = pygame.Rect(player_x, player_y, int(50 * 1.25), 50)
                        if laser_rect.colliderect(player_rect) and not laser_hit_dealt:
                            player_health -= 20.0
                            laser_hit_dealt = True

                if warning_timer > 0:
                    warning_timer -= 1

                # Player Movement inside Boss Battle
                keys = pygame.key.get_pressed()
                if active_debuff != "frozen":
                    move_dir_y = 0
                    move_dir_x = 0
                    
                    if keys[pygame.K_w]:
                        move_dir_y -= 1
                    if keys[pygame.K_s]:
                        move_dir_y += 1
                    if keys[pygame.K_a]:
                        move_dir_x -= 1
                        player_facing_left = True
                    if keys[pygame.K_d]:
                        move_dir_x += 1
                        player_facing_left = False

                    if active_debuff == "inverted":
                        move_dir_y *= -1
                        move_dir_x *= -1

                    player_x += move_dir_x * player_speed
                    player_y += move_dir_y * player_speed

                # Arena bounds
                if player_x < 100: player_x = 100
                if player_x > game_width - 150 - 50: player_x = game_width - 150 - 50
                if player_y < 120: player_y = 120
                if player_y > game_height - 80 - 50: player_y = game_height - 80 - 50

                # BOSS VISIBILITY & ATTACK RENDERING TOGGLE:
                if necro_is_dead and death_frames:
                    current_death_img = death_frames[min(necro_death_anim_index, len(death_frames) - 1)]
                    flipped_death = pygame.transform.flip(current_death_img, True, False)
                    flipped_death.set_alpha(dialogue_alpha)
                    screen.blit(flipped_death, (game_width - flipped_death.get_width() - 80, game_height/2 - flipped_death.get_height()/2))
                elif slam_anim_active and slam_frames:
                    current_slam_img = slam_frames[min(slam_seq_index, len(slam_frames)-1)]
                    flipped_slam = pygame.transform.flip(current_slam_img, True, False)
                    flipped_slam.set_alpha(dialogue_alpha)
                    screen.blit(flipped_slam, (game_width - flipped_slam.get_width() - 80, game_height/2 - flipped_slam.get_height()/2))
                elif spell_anim_active and spell_frames:
                    current_spell_img = spell_frames[min(spell_seq_index, len(spell_frames)-1)]
                    flipped_spell = pygame.transform.flip(current_spell_img, True, False)
                    flipped_spell.set_alpha(dialogue_alpha)
                    screen.blit(flipped_spell, (game_width - flipped_spell.get_width() - 80, game_height/2 - flipped_spell.get_height()/2))
                elif laser_charging:
                    necromancer_anim_timer -= 1
                    if necromancer_anim_timer <= 0:
                        necromancer_anim_timer = necromancer_anim_timer_max
                        necromancer_frame_index = (necromancer_frame_index + 1) % len(necromancer_raw_frames)
                    current_necro_img = pygame.transform.scale(necromancer_raw_frames[necromancer_frame_index], (414, 404)).convert_alpha()
                    flipped_necro_img = pygame.transform.flip(current_necro_img, True, False)
                    screen.blit(flipped_necro_img, (game_width - flipped_necro_img.get_width() - 80, game_height/2 - flipped_necro_img.get_height()/2))
                    
                    # Draw charge telegraph line at locked Y position
                    charge_line_surf = pygame.Surface((game_width, 10))
                    charge_line_surf.fill((255, 50, 50))
                    charge_line_surf.set_alpha(150)
                    screen.blit(charge_line_surf, (0, locked_laser_y + 20))
                elif laser_active and laser_frames:
                    current_laser_img = laser_frames[laser_seq_index]
                    boss_x_pos = game_width - 80 - 414
                    laser_draw_x = boss_x_pos - current_laser_img.get_width() + 100
                    laser_draw_y = locked_laser_y - current_laser_img.get_height()/2 + 25
                    screen.blit(current_laser_img, (laser_draw_x, laser_draw_y))
                else:
                    necromancer_anim_timer -= 1
                    if necromancer_anim_timer <= 0:
                        necromancer_anim_timer = necromancer_anim_timer_max
                        necromancer_frame_index = (necromancer_frame_index + 1) % len(necromancer_raw_frames)
                    
                    current_necro_img = pygame.transform.scale(necromancer_raw_frames[necromancer_frame_index], (414, 404)).convert_alpha()
                    flipped_necro_img = pygame.transform.flip(current_necro_img, True, False)
                    flipped_necro_img.set_alpha(dialogue_alpha)
                    screen.blit(flipped_necro_img, (game_width - flipped_necro_img.get_width() - 80, game_height/2 - flipped_necro_img.get_height()/2))
                
                # --- NECROMANCER HEALTH BAR UI ---
                bar_width = 400
                bar_height = 24
                bar_x = game_width / 2 - bar_width / 2
                bar_y = 50

                pygame.draw.rect(screen, (30, 20, 35), (bar_x, bar_y, bar_width, bar_height), border_radius=6)
                current_health_width = int(bar_width * (max(0.0, necro_health) / necro_max_health))
                if current_health_width > 0:
                    pygame.draw.rect(screen, (180, 30, 50), (bar_x, bar_y, current_health_width, bar_height), border_radius=6)
                pygame.draw.rect(screen, (200, 180, 220), (bar_x, bar_y, bar_width, bar_height), 2, border_radius=6)

                boss_label = small_font.render("NECROMANCER", True, (220, 200, 240))
                screen.blit(boss_label, (game_width/2 - boss_label.get_width()/2, bar_y - 28))

                # --- WARNING / DEBUFF UI NOTIFICATIONS ---
                if warning_timer > 0:
                    warn_surf = souls_font.render(warning_message, True, (255, 50, 50))
                    screen.blit(warn_surf, (game_width/2 - warn_surf.get_width()/2, 110))

                if active_debuff == "inverted":
                    inv_surf = small_font.render("CONTROLS INVERTED!", True, (255, 160, 50))
                    screen.blit(inv_surf, (game_width/2 - inv_surf.get_width()/2, 110))
                elif active_debuff == "frozen":
                    frz_surf = small_font.render("FROZEN IN PLACE!", True, (100, 200, 255))
                    screen.blit(frz_surf, (game_width/2 - frz_surf.get_width()/2, 110))

            elif boss_match_over:
                # --- WIN / LOSS SCREEN DISPLAY ---
                result_surf = souls_font.render(boss_result_text, True, (255, 255, 255))
                screen.blit(result_surf, (game_width/2 - result_surf.get_width()/2, game_height/2 - 30))

            # --- RENDER PLAYER & PLAYER HEALTH BAR DURING ALL BOSS_DIALOGUE SUB-STATES ---
            if not boss_match_over:
                boss_player_img = pygame.transform.scale(player_pic, (int(50 * 1.25), 50))
                if player_facing_left:
                    boss_player_img = pygame.transform.flip(boss_player_img, True, False)
                boss_player_img.set_alpha(255)
                screen.blit(boss_player_img, (player_x, player_y))

                p_bar_w = 60
                p_bar_h = 8
                p_bar_x = player_x + (50 * 1.25 / 2) - p_bar_w / 2
                p_bar_y = player_y - 15
                pygame.draw.rect(screen, (30, 30, 30), (p_bar_x, p_bar_y, p_bar_w, p_bar_h), border_radius=3)
                curr_p_w = int(p_bar_w * (max(0.0, player_health) / player_max_health))
                if curr_p_w > 0:
                    pygame.draw.rect(screen, (50, 220, 50), (p_bar_x, p_bar_y, curr_p_w, p_bar_h), border_radius=3)
                pygame.draw.rect(screen, (200, 200, 200), (p_bar_x, p_bar_y, p_bar_w, p_bar_h), 1, border_radius=3)

        elif game_state == "game":
            if player_alive and not transitioning:
                keys = pygame.key.get_pressed()
                if keys[pygame.K_a]:
                    player_x -= player_speed
                    player_facing_left = True
                if keys[pygame.K_d]:
                    player_x += player_speed
                    player_facing_left = False
                if keys[pygame.K_w]:
                    player_y -= player_speed
                if keys[pygame.K_s]:
                    player_y += player_speed
                if keys[pygame.K_SPACE]:
                    player_size += 2

                if player_x < 0:
                    player_x = 0
                if player_x > game_width - player_size * 1.25:
                    player_x = game_width - player_size * 1.25
                if player_y < 0:
                    player_y = 0
                if player_y > game_height - player_size:
                    player_y = game_height - player_size

                enemy_timer -= 1
                if enemy_timer <= 0:
                    new_enemy_y = random.randint(0, game_height)
                    new_enemy_speed = random.randint(2, 6)
                    new_enemy_size = random.randint(int(player_size/2.5), int(player_size*1.5))
                    if random.randint(0, 1) == 0:
                        enemies.append(Enemy(-new_enemy_size*2, new_enemy_y, new_enemy_speed, new_enemy_size))
                    else:
                        enemies.append(Enemy(game_width, new_enemy_y, -new_enemy_speed, new_enemy_size))
                    enemy_timer = enemy_timer_max

            for enemy in enemies_to_remove:
                if enemy in enemies:
                    enemies.remove(enemy)
            enemies_to_remove = []

            for enemy in enemies:
                enemy.update(screen)
                if enemy.x < -1000 or enemy.x > game_width + 1000:
                    enemies_to_remove.append(enemy)

            if player_alive:
                player_hitbox.x = player_x
                player_hitbox.y = player_y
                player_hitbox.width = int(player_size * 1.25)
                player_hitbox.height = player_size

                if not transitioning:
                    for enemy in enemies[:]:
                        if player_hitbox.colliderect(enemy.hitbox):
                            if player_size >= enemy.size:
                                player_size += 2
                                souls += 1
                                total_souls += 1
                                enemies.remove(enemy)
                                player_eating_timer = player_eating_timer_max
                                random.choice(eat_sounds).play()
                                
                                if total_souls >= 100 and not transitioning:
                                    spooky_transition_sound.play()
                                    transitioning = True
                                    transition_type = "whirlpool"
                                    transition_progress = 0.0
                                    next_state = "boss_dialogue"
                                    dialogue_step = 0
                                    dialogue_finished = False
                                    dialogue_alpha = 0
                                    boss_opening_active = False
                                    necro_health = 100.0
                                    necro_is_dead = False
                                    necro_death_anim_index = 0
                                    necro_death_anim_timer = 0
                                    player_health = 100.0
                                    boss_match_over = False
                            else:
                                player_alive = False

                player_swimming_timer -= 1
                if player_swimming_timer <= 0:
                    player_swimming_timer = player_swimming_timer_max
                    player_swimming_frame += 1
                    if player_swimming_frame > 1:
                        player_swimming_frame = 0

                if player_eating_timer > 0:
                    player_pic_small = pygame.transform.scale(player_eating_pic, (int(player_size*1.25), player_size))
                    player_eating_timer -= 1
                else:
                    if player_swimming_frame == 0:
                        player_pic_small = pygame.transform.scale(player_pic, (int(player_size*1.25), player_size))
                    else:
                        player_pic_small = pygame.transform.scale(player_pic2, (int(player_size*1.25), player_size))
                if player_facing_left:
                    player_pic_small = pygame.transform.flip(player_pic_small, True, False)

                if transitioning and transition_type == "whirlpool":
                    target_x = game_width / 2
                    target_y = game_height / 2
                    player_x += (target_x - player_x) * 0.08
                    player_y += (target_y - player_y) * 0.08
                    current_draw_size = max(2, int(player_size * (1.0 - transition_progress)))
                    player_pic_small = pygame.transform.scale(player_pic_small, (int(current_draw_size * 1.25), current_draw_size))

                screen.blit(player_pic_small, (player_x, player_y))
                
            if player_alive:
                souls_text = souls_font.render(f"Souls: {souls}", True, (130, 0, 0))
            else:
                souls_text = souls_font.render(f"TOTAL SOULS: {total_souls}", True, (80, 0, 0))
        
            screen.blit(souls_text, (30, 30))

            if not player_alive:
                screen.blit(play_button_pic, (play_button_x, play_button_y))
                screen.blit(title_pic, (title_x, title_y))
                draw_upgrades_button()

        elif game_state == "menu":
            screen.blit(title_pic, (title_x, title_y))
            screen.blit(play_button_pic, (play_button_x, play_button_y))
            draw_upgrades_button()
            
            total_souls_text = souls_font.render(f"TOTAL SOULS: {total_souls}", True, (80, 0, 0))
            screen.blit(total_souls_text, (30, 30))

        elif game_state == "upgrades":
            coming_soon_text = souls_font.render("Coming Soon", True, (255, 255, 255))
            back_text = souls_font.render("Click anywhere to return", True, (180, 180, 180))
            screen.blit(coming_soon_text, (game_width/2 - coming_soon_text.get_width()/2, game_height/2 - 40))
            screen.blit(back_text, (game_width/2 - back_text.get_width()/2, game_height/2 + 20))

        if transitioning:
            transition_progress += 0.015

            if transition_type == "whirlpool":
                whirlpool_angle += 8
                whs = int(400 * (1.0 - transition_progress * 0.5))
                if whs > 0:
                    rotated_wp = pygame.transform.rotate(whirlpool_pic, whirlpool_angle)
                    scaled_wp = pygame.transform.scale(rotated_wp, (whs, whs))
                    wp_rect = scaled_wp.get_rect(center=(game_width/2, game_height/2))
                    screen.blit(scaled_wp, wp_rect.topleft)

            elif transition_type == "bubble":
                for r in range(rows):
                    for c in range(cols):
                        offset = bubble_offsets[r][c]
                        local_p = (transition_progress - offset) / 0.7
                        local_p = max(0.0, min(1.0, local_p))
                        
                        if local_p > 0:
                            if local_p < 0.5:
                                scale_factor = local_p * 2.5
                                alpha = int(local_p * 510)
                            else:
                                scale_factor = (1.0 - local_p) * 2.5
                                alpha = int((1.0 - local_p) * 510)
                            
                            alpha = max(0, min(255, alpha))
                            current_size = int(bubble_size_grid * scale_factor)
                            
                            if current_size > 2:
                                bub_surf = pygame.transform.scale(bubble_pic, (current_size, current_size))
                                bub_surf.set_alpha(alpha)
                                bx = c * bubble_size_grid + (bubble_size_grid - current_size) // 2
                                by = r * bubble_size_grid + (bubble_size_grid - current_size) // 2
                                screen.blit(bub_surf, (bx, by))
            elif transition_type == "fade":
                fade_alpha = 0
                if transition_progress < 0.5:
                    fade_alpha = int(transition_progress * 510)
                else:
                    fade_alpha = int((1.0 - transition_progress) * 510)
                fade_alpha = max(0, min(255, fade_alpha))
                
                fade_surf = pygame.Surface((game_width, game_height))
                fade_surf.fill((0, 0, 0))
                fade_surf.set_alpha(fade_alpha)
                screen.blit(fade_surf, (0, 0))

            if transition_progress >= 0.5:
                if next_state in ["game", "restart_game"]:
                    game_state = "game"
                    player_alive = True
                    souls = 0
                    player_x = player_starting_x
                    player_y = player_starting_y
                    player_size = player_starting_size
                    enemies.clear()
                elif game_state != next_state:
                    game_state = next_state
                    if game_state == "boss_dialogue":
                        play_voice("player1")

            if transition_progress >= 1.0:
                transitioning = False

        pygame.display.flip()
        clock.tick(60)
        pygame.display.set_caption("Abyss fps: " + str(int(clock.get_fps())))
        
        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())